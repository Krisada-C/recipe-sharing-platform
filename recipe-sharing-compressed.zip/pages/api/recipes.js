import dbConnect from '@/utils/dbConnect';
import Recipe from '@/models/Recipe';

export default async function handler(req, res) {
  await dbConnect();
  
  if (req.method === 'POST') {
    const { title, ingredients, steps, cookingTime, image, category } = req.body;
    const recipe = new Recipe({ title, ingredients, steps, cookingTime, image, category });
    await recipe.save();
    return res.status(201).json(recipe);
  }
  // Handle GET, PUT, DELETE methods for reading, updating, and deleting recipes
}
